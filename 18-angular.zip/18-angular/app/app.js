var myNinjaApp = angular.module('myApp', ['ngRoute']);

myNinjaApp.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'views/home.html'
        })
        .when('/directory', {
            templateUrl: 'views/directory.html',
            controller: 'NinjaController'
        })
        .otherwise({
            redirectTo: '/'
        });
}]);
// myNinjaApp.run(function () {});

myNinjaApp.controller("NinjaController", function ($scope) {
    $scope.remove = function (meal) {
        var removeMeal = $scope.favMeal.indexOf(meal);
        $scope.favMeal.splice(removeMeal, 1);//removes the meal from the array
    }

    $scope.favMeal = [
        { 'name': 'Pizza', 'rating': 5, 'price': 160, available: true ,thumb:"content/img/pizza.png"},
        { 'name': 'Burger', 'rating': 4, 'price': 80, available: true ,thumb:"content/img/burger.png"},
        { 'name': 'Pasta', 'rating': 3, 'price': 120, available: false ,thumb:"content/img/pasta.png"},
        { 'name': 'Salad', 'rating': 2, 'price': 60, available: true ,thumb:"content/img/salad.png" },
        { 'name': 'Sushi', 'rating': 5, 'price': 200, available: false ,thumb:"content/img/sushi.png"},
        { 'name': 'Ice Cream', 'rating': 4, 'price': 50, available: true ,thumb:"content/img/ice-ream.png"}
    ];
    $scope.numbers = [1, 2, 3, 4];
    $scope.color = 'orange';
    $scope.ratings = [5, 4, 3, 2];

    $scope.getStars = function (rating) {
        return '⭐'.repeat(rating);
    };

    $scope.newMeal = {};


    $scope.addMeal = function () {
        $scope.favMeal.push({
            name: $scope.newMeal.name,
            price: Number($scope.newMeal.price),
            available: true,
            rating: Number($scope.newMeal.rating)
        });

        $scope.newMeal = {};
    };

    //  $scope.newMeal = {
    //     name: '',
    //     price: null,
    //     available: true,
    //     rating: null
    // };

    // $scope.addMeal = function() {
    //     // coerce numeric fields before adding
    //     $scope.newMeal.price = Number($scope.newMeal.price);
    //     $scope.newMeal.rating = Number($scope.newMeal.rating);
    //     $scope.favMeal.push($scope.newMeal);
    //     $scope.newMeal = { name: '', price: null, available: true, rating: null };
    // };
});